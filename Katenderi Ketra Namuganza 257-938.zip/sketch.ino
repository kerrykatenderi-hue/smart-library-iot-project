#define GREEN_LED 2
#define RED_LED 4
#define BUZZER 15

void setup() {

  Serial.begin(115200);

  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);

  Serial.println("SMART LIBRARY RFID SECURITY SYSTEM");
}

void loop() {

  // AUTHORIZED BOOK
  Serial.println("AUTHORIZED BOOK DETECTED");

  digitalWrite(GREEN_LED, HIGH);
  digitalWrite(RED_LED, LOW);

  noTone(BUZZER);

  delay(3000);

  digitalWrite(GREEN_LED, LOW);

  delay(1000);

  // UNAUTHORIZED BOOK REMOVAL
  Serial.println("WARNING! UNAUTHORIZED BOOK REMOVAL!");

  digitalWrite(RED_LED, HIGH);

  tone(BUZZER, 1000);

  delay(3000);

  noTone(BUZZER);

  digitalWrite(RED_LED, LOW);

  delay(2000);
}